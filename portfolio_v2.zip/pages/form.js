import FormPageComp from "@/src/components/form";
export default FormPageComp