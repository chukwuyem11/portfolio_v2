import ResumePageComp from "@/src/components/cv_page";

export default ResumePageComp;
