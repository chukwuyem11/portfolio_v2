import DivardHomePage from "@/src/diarvd/components/home_page";

export default DivardHomePage
